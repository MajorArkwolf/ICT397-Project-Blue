#include <cstddef>

#include "Controller/Engine/Engine.hpp"

int main([[maybe_unused]] int argc, [[maybe_unused]] char **argv) {
    BlueEngine::Engine::run();

    return EXIT_SUCCESS;
}