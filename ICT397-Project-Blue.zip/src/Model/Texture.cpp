#include "Texture.hpp"

Texture::Texture(GLuint id, int h, int w) : TextureID(id), height(h), width(w) {}
